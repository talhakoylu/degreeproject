import {Text} from "@chakra-ui/react";

const AboutUsPage= ()=>{
    return(
        <Text>Sa</Text>
    )
}

export default AboutUsPage