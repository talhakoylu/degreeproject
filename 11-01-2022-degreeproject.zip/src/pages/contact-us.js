import {Text} from "@chakra-ui/react";
import StandardLayout from "../components/layouts/StandardLayout";

const ContactUsPage = ()=>{
    return(
        <StandardLayout>
            <Text>
                As
            </Text>
        </StandardLayout>
    )
}

export default ContactUsPage