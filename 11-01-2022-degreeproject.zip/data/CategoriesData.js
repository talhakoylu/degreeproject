export const CategoriesData = [
    {
        id: 1,
        title: "Category 1",
        description: "Category 1 description",
        image: "/assets/images/1.jpg",
        path: "/category-1"
    },
    {
        id: 2,
        title: "Category 2",
        description: "Category 2 description",
        image: "/assets/images/2.jpg",
        path: "/category-2"
    },
    {
        id: 3,
        title: "Category 3",
        description: "Category 3 description",
        image: "/assets/images/3.jpg",
        path: "/category-3"
    },
    {
        id: 4,
        title: "Category 4",
        description: "Category 4 description",
        image: "/assets/images/1.jpg",
        path: "/category-4"
    },
    {
        id: 5,
        title: "Category 5",
        description: "Category 5 description",
        image: "/assets/images/2.jpg",
        path: "/category-5"
    },
    {
        id: 6,
        title: "Category 6",
        description: "Category 6 description",
        image: "/assets/images/3.jpg",
        path: "/category-6"
    },
    {
        id: 7,
        title: "Category 7",
        description: "Category 7 description",
        image: "/assets/images/1.jpg",
        path: "/category-7"
    },
    {
        id: 8,
        title: "Category 8",
        description: "Category 8 description",
        image: "/assets/images/2.jpg",
        path: "/category-8"
    },
    {
        id: 9,
        title: "Category 9",
        description: "Category 9 description",
        image: "/assets/images/3.jpg",
        path: "/category-9"
    },
    {
        id: 10,
        title: "Category 10",
        description: "Category 10 description",
        image: "/assets/images/1.jpg",
        path: "/category-10"
    },
    {
        id: 11,
        title: "Category 11",
        description: "Category 11 description",
        image: "/assets/images/2.jpg",
        path: "/category-11"
    },
    {
        id: 12,
        title: "Category 12",
        description: "Category 12 description",
        image: "/assets/images/3.jpg",
        path: "/category-12"
    },
]