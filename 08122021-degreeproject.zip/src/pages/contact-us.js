import {Text} from "@chakra-ui/react";
import StandartLayout from "../components/layouts/StandartLayout";

const ContactUsPage = ()=>{
    return(
        <StandartLayout>
            <Text>
                As
            </Text>
        </StandartLayout>
    )
}

export default ContactUsPage